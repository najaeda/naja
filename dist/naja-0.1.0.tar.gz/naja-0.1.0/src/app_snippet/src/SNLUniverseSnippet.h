// SPDX-FileCopyrightText: 2023 The Naja authors <https://github.com/najaeda/naja/blob/main/AUTHORS>
//
// SPDX-License-Identifier: Apache-2.0

#ifndef __SNL_UNIVERSE_SNIPPET_H_
#define __SNL_UNIVERSE_SNIPPET_H_

class SNLUniverseSnippet {
  public:
    static void create();
};

#endif /* __SNL_UNIVERSE_SNIPPET_H_ */