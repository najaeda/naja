// SPDX-FileCopyrightText: 2023 The Naja authors <https://github.com/najaeda/naja/blob/main/AUTHORS>
//
// SPDX-License-Identifier: Apache-2.0

#include "SNLObject.h"

namespace naja { namespace SNL {

void SNLObject::preCreate() {
  super::preCreate();
}

void SNLObject::postCreate() {
  super::postCreate();
}

void SNLObject::preDestroy() {
  super::preDestroy();
}

}} // namespace SNL // namespace naja