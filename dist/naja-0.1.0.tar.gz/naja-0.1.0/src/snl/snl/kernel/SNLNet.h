// SPDX-FileCopyrightText: 2023 The Naja authors <https://github.com/najaeda/naja/blob/main/AUTHORS>
//
// SPDX-License-Identifier: Apache-2.0

#ifndef __SNL_NET_H_
#define __SNL_NET_H_

#include <boost/intrusive/set.hpp>

#include "SNLName.h"
#include "SNLDesignObject.h"

namespace naja { namespace SNL {

class SNLBitNet;

class SNLNet: public SNLDesignObject {
  public:
    friend class SNLDesign;
    using super = SNLDesignObject;

    class Type {
      public:
        enum TypeEnum {
          Standard, Assign0, Assign1, Supply0, Supply1
        };
        Type(const TypeEnum& typeEnum);
        Type(const Type&) = default;
        Type& operator=(const Type&) = default;
        bool operator==(const Type& other) const {
          return typeEnum_ == other.typeEnum_;
        }
        bool operator==(const TypeEnum& otherEnum) const {
          return typeEnum_ == otherEnum;
        }

        operator const TypeEnum&() const { return typeEnum_; }
        constexpr bool isAssign0() const { return typeEnum_ == Assign0;  }
        constexpr bool isAssign1() const { return typeEnum_ == Assign1;  }
        constexpr bool isAssign() const { return isAssign0() or isAssign1(); }
        constexpr bool isSupply0() const { return typeEnum_ == Supply0; }
        constexpr bool isSupply1() const { return typeEnum_ == Supply1; }
        constexpr bool isSupply() const { return isSupply0() or isSupply1(); }
        constexpr bool isConst0() const { return typeEnum_ == Assign0 or typeEnum_ == Supply0; }
        constexpr bool isConst1() const { return typeEnum_ == Assign1 or typeEnum_ == Supply1; }
        constexpr bool isDriving() const { return isAssign() or isSupply(); }
        std::string getString() const;
      private:
        TypeEnum typeEnum_;
    };

    SNLID::DesignObjectReference getReference() const;
    /// \return this SNLNet unique ID in parent SNLDesign.
    virtual SNLID::DesignObjectID getID() const = 0;

    /// \return net SNLName.
    virtual SNLName getName() const = 0;
    
    /// \return net size, 1 for SNLScalarNet and SNLBusNetBit.
    virtual SNLID::Bit getSize() const = 0;

    /**
     * \return this SNLNet SNLBitNet collection.
     * 
     * Will return itself for SNLScalarNet and SNLBusNetBit and a collection
     * of SNLBusNetBit for SNLBusNet.
     */ 
    virtual NajaCollection<SNLBitNet*> getBits() const = 0;

    /// \brief Change this SNLNet type. 
    virtual void setType(const Type& type) = 0;

    /// \return true if all bits of this net are assigned to 1'b0 or 1'b1.
    virtual bool isAssignConstant() const = 0;
    ///\return true if all bits of this net are of type Supply0
    virtual bool isSupply0() const = 0;
    ///\return true if all bits of this net are of type Supply1
    virtual bool isSupply1() const = 0;

    virtual bool deepCompare(const SNLNet* other, std::string& reason) const = 0;

  protected:
    SNLNet() = default;

    static void preCreate();
    void postCreate();
    void preDestroy() override;

  private:
    virtual void destroyFromDesign() = 0;
    virtual SNLNet* clone(SNLDesign* design) const = 0;

    //following used in BusNet and ScalarNet
    virtual void setID(SNLID::DesignObjectID id) = 0;
    boost::intrusive::set_member_hook<> designNetsHook_ {};
};

}} // namespace SNL // namespace naja

#endif // __SNL_NET_H_
