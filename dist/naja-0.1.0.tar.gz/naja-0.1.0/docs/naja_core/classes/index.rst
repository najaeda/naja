Naja core classes
=================

.. doxygenclass:: naja::NajaObject
   :members:

.. doxygenclass:: naja::NajaProperty
   :members:

.. doxygenclass:: naja::NajaPrivateProperty
   :members:

.. doxygenclass:: naja::NajaDumpableProperty
   :members: