SNL Connectivity Classes
========================

.. doxygenclass:: naja::SNL::SNLNet
   :members:

.. doxygenclass:: naja::SNL::SNLBusNet
   :members:

.. doxygenclass:: naja::SNL::SNLBitNet
   :members:

.. doxygenclass:: naja::SNL::SNLBusNetBit
   :members:

.. doxygenclass:: naja::SNL::SNLScalarNet
   :members: