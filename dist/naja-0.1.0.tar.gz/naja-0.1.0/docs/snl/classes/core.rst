SNL Core Classes
================

.. doxygenclass:: naja::SNL::SNLName
   :members:

.. doxygenclass:: naja::SNL::SNLObject
   :members:

.. doxygenstruct:: naja::SNL::SNLID
   :members: