Occurrence Classes
==================

.. doxygenclass:: naja::SNL::SNLPath
   :members:

.. doxygenclass:: naja::SNL::SNLOccurrence
   :members:

.. doxygenclass:: naja::SNL::SNLNetComponentOccurrence
   :members:

.. doxygenclass:: naja::SNL::SNLNetComponentOccurrence
   :members:

.. doxygenclass:: naja::SNL::SNLBitTermOccurrence
   :members:

.. doxygenclass:: naja::SNL::SNLBitNetOccurrence
   :members: