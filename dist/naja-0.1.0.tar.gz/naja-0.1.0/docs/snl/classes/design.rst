SNL Design and Instance Classes
===============================

.. doxygenclass:: naja::SNL::SNLDesignObject
   :members:

.. doxygenclass:: naja::SNL::SNLDesign
   :members:

.. doxygenclass:: naja::SNL::SNLParameter
   :members:

.. doxygenclass:: naja::SNL::SNLInstance
   :members:

.. doxygenclass:: naja::SNL::SNLInstParameter
   :members: